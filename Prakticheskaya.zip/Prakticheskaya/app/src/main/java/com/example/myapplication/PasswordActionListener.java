package com.example.myapplication;

public interface PasswordActionListener {
    void onDeletePassword(int passwordId);
}